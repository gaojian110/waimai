
// 测试环境
// export const baseUrl = 'http://reggie-dev.itheima.net'
// 线上环境
export const baseUrl = 'https://registakeaway.itheima.net'